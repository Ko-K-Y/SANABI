// Copyright Epic Games, Inc. All Rights Reserved.

#include "GEB_Project.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, GEB_Project, "GEB_Project" );
 