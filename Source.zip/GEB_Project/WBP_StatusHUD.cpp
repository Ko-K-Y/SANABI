#include "WBP_StatusHUD.h"
#include "HealthComponent.h"
#include "Engine/Engine.h"


void UWBP_StatusHUD::SetHealth(UHealthComponent* InHealth)
{
    if (Health == InHealth) return;

    // ���� ���ε� Ǯ��
    if (Health)
    {
        Health->OnHealthChanged.RemoveAll(this);
        Health->OnDeath.RemoveAll(this);
    }

    Health = InHealth;

    if (Health)
    {
        // ��������Ʈ ���ε�
        Health->OnHealthChanged.AddDynamic(this, &UWBP_StatusHUD::HandleHealthChanged);
        Health->OnDeath.AddDynamic(this, &UWBP_StatusHUD::HandleDeath);

        // �ʱ� 1ȸ ����
        HandleHealthChanged(
            Health->GetCurrentHealth_Implementation(),
            Health->GetMaxHealth_Implementation());
    }
    if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 2.0f, FColor::Cyan, TEXT("SetHealth called"));
}

void UWBP_StatusHUD::HandleHealthChanged(int32 Current, int32 Max)
{
    UpdateHearts(Current, Max);   // BP�� UpdateHearts ȣ��
    if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 2.0f, FColor::Yellow,
        FString::Printf(TEXT("HandleHealthChanged C=%d M=%d"), Current, Max));
}

void UWBP_StatusHUD::HandleDeath()
{
    // �ʿ��ϸ� ��� UI ó��
}
