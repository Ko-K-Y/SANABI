#pragma once
#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "PlayerProgressGameInstance.generated.h"

UCLASS()
class GEB_PROJECT_API UPlayerProgressGameInstance : public UGameInstance
{
    GENERATED_BODY()
public:
    // �����ص� ��
    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Progress")
    int32 SavedLevel = 1;

    UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Progress")
    int32 SavedCurExp = 0;

    // ������Ʈ -> GI�� ����
    UFUNCTION(BlueprintCallable, Category = "Progress")
    void CaptureFrom(class UExperienceComponent* XP);

    // GI -> ������Ʈ�� ����
    UFUNCTION(BlueprintCallable, Category = "Progress")
    void ApplyTo(class UExperienceComponent* XP) const;
};
