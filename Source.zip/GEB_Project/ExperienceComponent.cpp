// ExperienceComponent.cpp
#include "ExperienceComponent.h"
#include "Engine/Engine.h"

UExperienceComponent::UExperienceComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
	ExpToLevel = CalcExpToNext(Level);
}

void UExperienceComponent::BeginPlay()
{
	Super::BeginPlay();
	ExpToLevel = CalcExpToNext(Level);
	// ���� �� �ѹ� ��ε�ĳ��Ʈ�ؼ� HUD�� ��� ���ŵǰ� �� ���� ����
	OnExpChanged.Broadcast(CurExp, ExpToLevel);
}

void UExperienceComponent::AddEXP(int32 Amount)
{
	if (Amount <= 0) return;

	CurExp += Amount;
	bool bLeveled = false;

	// ���� ���� ���� ��µ� ó��
	while (CurExp >= ExpToLevel)
	{
		CurExp -= ExpToLevel;
		Level++;
		ExpToLevel = CalcExpToNext(Level);
		bLeveled = true;

		OnLevelUp.Broadcast(Level);
	}

	OnExpChanged.Broadcast(CurExp, ExpToLevel);

#if !UE_BUILD_SHIPPING
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(
			-1, 2.5f, FColor::Yellow,
			FString::Printf(TEXT("[EXP] Lv.%d  %d / %d%s"),
				Level, CurExp, ExpToLevel, bLeveled ? TEXT("  (LEVEL UP!)") : TEXT("")));
	}
#endif
}

void UExperienceComponent::LoadState(int32 InLevel, int32 InCurExp, int32 InExpToLevel)
{
	Level = InLevel;
	CurExp = InCurExp;
	ExpToLevel = (InExpToLevel > 0) ? InExpToLevel : CalcExpToNext(Level);

	// UI ��� ���� �̺�Ʈ
	OnExpChanged.Broadcast(CurExp, ExpToLevel);
}
