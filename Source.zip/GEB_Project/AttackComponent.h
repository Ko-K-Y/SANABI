// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Attack.h"
#include "AttackComponent.generated.h"

class UCapsuleComponent;

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class GEB_PROJECT_API UAttackComponent : public UActorComponent, public IAttack
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UAttackComponent();


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AttackSocket")
	TArray<FName> AttackSocketNames;

	// ���Ͽ� ���� ĸ�� �ݰ�/�ݳ��� (��������Ʈ ����)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AttackSocket")
	float AttackCapsuleRadius = 20.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AttackSocket")
	float AttackCapsuleHalfHeight = 40.f;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AttackStat", meta = (AllowPrivateAccess = "true"))
	int32 damage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AttackStat", meta = (AllowPrivateAccess = "true"))
	float maxAttackCoolTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AttackStat", meta = (AllowPrivateAccess = "true"))
	float attackRange;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AttackStat", meta = (AllowPrivateAccess = "true"))
	bool isCooldown;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AttackStat", meta = (AllowPrivateAccess = "true"))
	float coolTime;

	// ��Ÿ�ӿ� ������ ���Ͽ� ĸ�� ������Ʈ��
	UPROPERTY()
	TArray<UCapsuleComponent*> SocketCapsules;

	// ���� ���� �߿� �̹� ��Ʈ�� ���� ���� (�ߺ� ����)
	TSet<TWeakObjectPtr<AActor>> RecentlyHitActors;

public:	
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	virtual void PerformAttack_Implementation();
	virtual bool GetisCoolDown_Implementation();
	virtual float GetattackRange_Implementation();

	void OnAttackHit(AActor* Target);

	// ĸ�� �ݶ��̴� ������ �ݹ�
	UFUNCTION()
	void OnSocketOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	                          UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
};
