// Fill out your copyright notice in the Description page of Project Settings.


#include "ShieldInterface.h"

// Add default functionality here for any IShieldInterface functions that are not pure virtual.
