#include "PlayerProgressGameInstance.h"
#include "ExperienceComponent.h"

void UPlayerProgressGameInstance::CaptureFrom(UExperienceComponent* XP)
{
    if (!XP) return;
    SavedLevel = XP->GetLevel();
    SavedCurExp = XP->GetCurExp();
}

void UPlayerProgressGameInstance::ApplyTo(UExperienceComponent* XP) const
{
    if (!XP) return;

    // �Լ� �̸� �ݵ�� LoadState��!
    XP->LoadState(SavedLevel, SavedCurExp, /*InExpToLevel=*/0);
}
